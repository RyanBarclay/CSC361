Ryan's readme.txt

OK so to run this is pretty easy. 

So you've done step 1, which is unzipping the file. Good Job!

Step 2, make sure all files unzipped are in the same directory.

Step 3, go to that directory.

Ok now type:
python3 a2.py <cap_file> 

and if you want to export to txt using piping with 
python3 a2.py <cap_file>  > <text_output_file> 

NOTE: Please use basic_structures.py included with zip, as it was heavily edited.

Please have mercy on my soul,

Ryan 

V00842513