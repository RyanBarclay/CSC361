Ryan Barclay
V00842513

To run code type:
python3 SmartClient.py <URL>

Some notes:
I duplicate cookies, as in show the total cookies from the http/1.1 and https cookies